function xdot = trolly_fuzzy(t, x);
global A0 A1 A2 B0 B1 B2 u M m;
if(x(3)==0)
    h0=1;
else
    h0=sin(x(3))/x(3);
end
h1=(1-h0)/2;h2=h1;
xdot=h0*(A0*x+B0*u)+h1*(A1*x+B1*u)+h2*(A2*x+B2*u); 
