clear all;close all;
t0=0;tf=30;step=0.1;
x0(1:4)=[10 1 pi/10 0.1]';
global M m l u g;
global A0 A1 A2 B0 B1 B2 x3 K0 K1 K2;
M=100;m=50;l=4;g=9.81;u=100;
syms x1 x2 x3 x4;
x00=[0 0 0 0]';x01=[5 0 pi/6 pi/20]';x02=[5 -1 -pi/6 0]';
x=[x1;x2;x3;x4];
f=[x2;(m*l*x4^2*sin(x3)+m*g*sin(x3)*cos(x3))/(M+m*sin(x3)*sin(x3));x4;-(m*l*x4^2*sin(x3)*cos(x3)+(M+m)*g*sin(x3))/l/(M+m*sin(x3)*sin(x3))];
gx=1/(M+m*sin(x3)*sin(x3))*[0;1;0;-cos(x3)/l];
J=jacobian(f,x);
Ai=J+(f-J*x)*x'/(x'*x);
A0=double(subs(J,x,x00));B0=double(subs(gx,x,x00));
A1=double(subs(Ai,x,x01));B1=double(subs(gx,x,x01));
A2=double(subs(Ai,x,x02));B2=double(subs(gx,x,x02));

[t,x_fuzzy]=ode45('trolly_fuzzy',[t0:step:tf], x0);
[t,x_affine]=ode45('trolly_affine',[t0:step:tf], x0);
figure(1);
subplot(2,2,1);plot(t, x_fuzzy(:,1),'b-.',t,x_affine(:,1),'b:');xlabel('时间(秒)');ylabel('x1');
subplot(2,2,2);plot(t, x_fuzzy(:,2),'b-.',t,x_affine(:,2),'b:');xlabel('时间(秒)');ylabel('x2');
subplot(2,2,3);plot(t, x_fuzzy(:,3),'b-.',t,x_affine(:,3),'b:');xlabel('时间(秒)');ylabel('x3');
subplot(2,2,4);plot(t, x_fuzzy(:,4),'b-.',t,x_affine(:,4),'b:');xlabel('时间(秒)');ylabel('x4');

a0=[-1.1 -1.5 -1.8 -2.1];
a1=[-1.3 -1.6 -1.9 -2.2];
a2=[-1.5 -1.6 -1.8 -1.9];
K0=place(A0,B0,a0);K1=place(A1,B1,a1);K2=place(A2,B2,a2);

[t,x_fuzzy_ctrl]=ode45('trolly_fuzzy_ctrl',[t0:step:tf], x0);
[t,x_affine_ctrl]=ode45('trolly_affine_ctrl',[t0:step:tf], x0);
figure(2);
subplot(2,2,1);plot(t, x_fuzzy_ctrl(:,1),'b-.',t,x_affine_ctrl(:,1),'b:');xlabel('时间(秒)');ylabel('x1');
subplot(2,2,2);plot(t, x_fuzzy_ctrl(:,2),'b-.',t,x_affine_ctrl(:,2),'b:');xlabel('时间(秒)');ylabel('x2');
subplot(2,2,3);plot(t, x_fuzzy_ctrl(:,3),'b-.',t,x_affine_ctrl(:,3),'b:');xlabel('时间(秒)');ylabel('x3');
subplot(2,2,4);plot(t, x_fuzzy_ctrl(:,4),'b-.',t,x_affine_ctrl(:,4),'b:');xlabel('时间(秒)');ylabel('x4');

