function xdot = trolly_affine(t, x);
global M m l u g;
f=[x(2);(m*l*x(4)^2*sin(x(3))+m*g*sin(x(3))*cos(x(3)))/(M+m*sin(x(3))*sin(x(3)));x(4);-(m*l*x(4)^2*sin(x(3))*cos(x(3))+(M+m)*g*sin(x(3)))/l/(M+m*sin(x(3))*sin(x(3)))];
gx=1/(M+m*sin(x(3))*sin(x(3)))*[0;1;0;-cos(x(3))/l];
xdot=f+gx*u;