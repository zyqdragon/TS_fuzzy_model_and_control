function xdot = trolly_fuzzy_ctrl(t, x);
global A0 A1 A2 B0 B1 B2 u M m K0 K1 K2;
if(x(3)==0)
    h0=1;
else
    h0=sin(x(3))/x(3);
end
h1=(1-h0)/2;h2=h1;
u0=u-h0*K0*x-h1*K1*x-h2*K2*x;
xdot=h0*(A0*x+B0*u0)+h1*(A1*x+B1*u0)+h2*(A2*x+B2*u0); 
