function xdot = trolly_affine_ctrl(t, x);
global M m l u g K0 K1 K2;
f=[x(2);(m*l*x(4)^2*sin(x(3))+m*g*sin(x(3))*cos(x(3)))/(M+m*sin(x(3))*sin(x(3)));x(4);-(m*l*x(4)^2*sin(x(3))*cos(x(3))+(M+m)*g*sin(x(3)))/l/(M+m*sin(x(3))*sin(x(3)))];
gx=1/(M+m*sin(x(3))*sin(x(3)))*[0;1;0;-cos(x(3))/l];
h0=M*(sin(x(3)))^2/(M+m*sin(x(3))*sin(x(3)));
h1=M*(cos(x(3)))^2/(M+m*sin(x(3))*sin(x(3)));
h2=m*(sin(x(3)))^2/(M+m*sin(x(3))*sin(x(3)));
xdot=f+gx*(u-h0*K0*x-h1*K1*x-h2*K2*x);